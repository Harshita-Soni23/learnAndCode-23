#pragma once

#include "client.h"
#include "requestHandler.h"

class ClientHandler {
public:
    ClientHandler(Client& client);
    void handleRequest();

private:
    Client& client;
    RequestHandler* requestHandler;

    void handleUserInput();
};
